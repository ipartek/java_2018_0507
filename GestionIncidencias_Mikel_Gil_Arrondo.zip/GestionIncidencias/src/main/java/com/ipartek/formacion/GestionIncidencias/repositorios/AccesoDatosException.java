package com.ipartek.formacion.GestionIncidencias.repositorios;

public class AccesoDatosException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AccesoDatosException() {
		// TODO Auto-generated constructor stub
	}

	public AccesoDatosException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AccesoDatosException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public AccesoDatosException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccesoDatosException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
